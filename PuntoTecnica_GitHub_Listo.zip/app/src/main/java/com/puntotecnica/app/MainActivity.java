package com.puntotecnica.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import android.view.Window;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle b){ super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
        web=new WebView(this); setContentView(web); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setBuiltInZoomControls(false); web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/index.html"); }
    public void imprimir(){ PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE); PrintDocumentAdapter a=web.createPrintDocumentAdapter("Punto_Tecnica_Presupuesto"); pm.print("Punto Técnica",a,new PrintAttributes.Builder().build()); }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
