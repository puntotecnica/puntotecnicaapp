# PUNTO TÉCNICA — Aplicación Android

Proyecto Android Studio preparado para compilar una APK.

## Incluye
- Logo 3D de PUNTO TÉCNICA.
- Dashboard.
- Clientes.
- Trabajos.
- Presupuestos.
- Stock y alertas.
- Gastos.
- Datos locales mediante LocalStorage.
- Interfaz adaptada a celular.

## Cómo obtener la APK
Abrir esta carpeta en Android Studio y ejecutar **Build > Build APK(s)**.
La APK de debug queda en `app/build/outputs/apk/debug/app-debug.apk`.
